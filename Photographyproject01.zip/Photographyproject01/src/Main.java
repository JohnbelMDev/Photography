import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
	// write your code here
        Scanner reader = new Scanner(System.in);

        System.out.printf("Hello this programs help/teach you to take better pictures\n");
        System.out.println("First, we will define the main three settings you need to understand before you start taking pictures. ");
        System.out.printf(" There are 3 settings you need to know about ISO, SHUTTER SPEED, APERTURE\n");
        System.out.printf("Please enter the settings of your iso\n");

        //this is a function to read your ISO setting
        iso1();
        System.out.printf(" Please enter the setting of your aperture:\n");
        aperture();
    }








    public static void iso1()
    {
        Scanner reader = new Scanner(System.in);
          int iso=reader.nextInt();

        if (iso < 100)
            System.out.printf("Your pictures will be \n");
        else if (iso >100 || iso >300)
            System.out.printf(" Your pictures will be bright if your're in a place that has low light, such as being inside your house.");
    }

    public static void aperture()
    {
        Scanner input = new Scanner(System.in);
        double aper =input.nextDouble();

        if (aper < 5.8)

            System.out.println("Your pictures will be bright if your're outdoor\n");

        else if (aper >5.8 || aper > 11.6)

            System.out.printf("Your pictures will be dark if your're in a dark environment");

    }

}
